#!/bin/bash
# ci-local.sh - Run tests locally with CI-like settings
# This simulates the CI environment for debugging test failures

set -e

echo "🔧 Running tests with CI settings..."
echo ""

# Set CI environment variable (used by Playwright for stricter settings)
export CI=true

# Run tests with chromium only (matches primary CI browser)
echo "📋 Running E2E tests (chromium)..."
npm run test:e2e -- --project=chromium

echo ""
echo "✅ CI simulation complete"
