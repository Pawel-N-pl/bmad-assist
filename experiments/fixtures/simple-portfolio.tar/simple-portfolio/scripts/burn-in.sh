#!/bin/bash
# burn-in.sh - Run burn-in loop locally for flaky test detection
# Usage: ./scripts/burn-in.sh [iterations]

set -e

ITERATIONS=${1:-5}

echo "🔥 Starting local burn-in loop ($ITERATIONS iterations)"
echo ""

export CI=true
FAILURES=0

for i in $(seq 1 $ITERATIONS); do
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "🔥 Burn-in iteration $i/$ITERATIONS"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  if ! npm run test:e2e -- --project=chromium; then
    FAILURES=$((FAILURES + 1))
    echo "⚠️ Iteration $i failed"
  fi
  echo ""
done

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ $FAILURES -gt 0 ]; then
  echo "❌ Burn-in detected $FAILURES failures in $ITERATIONS iterations"
  echo "   Review test-results/ and playwright-report/ for details"
  exit 1
else
  echo "✅ Burn-in complete - no flaky tests detected"
fi
