# UX Specification: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**UX Designer:** Sally
**Date:** 2025-12-11
**Status:** Approved

## User Persona

### Primary Persona: Potential Client

**Name:** Sarah Mitchell
**Age:** 28-45
**Context:** Planning a wedding, looking for a photographer

**Goals:**
- Quickly assess photographer's style and quality
- See relevant work samples (wedding photography)
- Easy way to make contact

**Behaviors:**
- Browses on mobile during commute (60% mobile traffic expected)
- Makes decisions based on visual first impression
- Scans, doesn't read - needs clear visual hierarchy
- Will leave if page loads slowly or looks unprofessional

**Pain Points:**
- Cluttered portfolios with too many options
- Slow-loading image galleries
- Unclear how to get in touch
- Sites that don't work on mobile

### Secondary Persona: Industry Peer

**Name:** Marcus Rivera
**Context:** Fellow photographer, potential collaborator

**Goals:**
- Evaluate Alex's style for collaboration fit
- Quick overview of specialties

## Visual Direction

### Mood & Tone

**Keywords:** Elegant, Professional, Minimal, Gallery-like

**Concept:** The website should feel like walking into a high-end photography gallery - clean walls, focused lighting, art speaks for itself.

**Visual Metaphor:** White-cube gallery meets premium magazine layout.

### Color Psychology

| Color | Token | Hex | Rationale |
|-------|-------|-----|-----------|
| Deep Navy | `--color-primary` | #1a1a2e | Sophisticated, timeless, makes photos "pop" |
| Coral Accent | `--color-accent` | #e94560 | Warm, inviting, draws eye to CTA |
| Clean White | `--color-background` | #ffffff | Gallery-like, maximizes photo contrast |
| Charcoal | `--color-text` | #333333 | Easy reading, softer than pure black |
| Muted Gray | `--color-text-light` | #666666 | Secondary info, doesn't compete |

**Why Dark Hero + Light Content:**
- Hero section uses `--color-primary` background → dramatic first impression
- Projects section uses `--color-background` → photos are the focus
- This contrast creates natural visual sections without heavy borders

### Typography Rationale

| Element | Font | Token | Rationale |
|---------|------|-------|-----------|
| Headings | Georgia | `--font-heading` | Serif = elegance, timelessness, art-world feel |
| Body | Arial | `--font-body` | Sans-serif = clarity, modern, easy scanning |

**Type Scale:**
- Hero name: `--font-size-xxl` (3rem) - Commanding presence
- Section titles: `--font-size-xl` (2rem) - Clear hierarchy
- Card titles: `--font-size-lg` (1.25rem) - Scannable
- Body: `--font-size-base` (16px) - Comfortable reading

## Layout Design

### Information Architecture

```
┌─────────────────────────────────────┐
│             HERO                    │  ← Emotional hook (3 seconds)
│   Name + Tagline + CTA              │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│           PORTFOLIO                 │  ← Proof of work
│   [Wedding] [Portrait] [Landscape]  │
└─────────────────────────────────────┘
```

**Why this order:**
1. Hero creates emotional connection first
2. Portfolio proves capability second
3. No navigation needed - single scroll journey

### Wireframes

**Mobile Layout (< 768px):**

```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (≥ 768px):**

```
┌────────────────────────────────────────────────────┐
│                                                    │
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                                                    │
│                  [ Get in Touch ]                  │
│                                                    │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

## Interaction Design

### CTA Button States

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text |
| Hover | Slightly darker accent, subtle scale (1.02) |
| Focus | Visible outline for accessibility |
| Active | Darker accent, scale down (0.98) |

### Project Card States

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**Note:** All hover effects use CSS transitions (0.2s ease) for smooth feel.

### Touch Targets

- CTA button: minimum 48x48px tap area
- Cards: entire card is tappable area on mobile
- Adequate spacing between interactive elements (min 8px)

## Accessibility Considerations

### Color Contrast

All text meets WCAG AA standards:
- `--color-text` (#333) on `--color-background` (#fff) = 12.6:1 ✓
- White text on `--color-primary` (#1a1a2e) = 15.1:1 ✓
- White text on `--color-accent` (#e94560) = 4.5:1 ✓

### Focus Indicators

- All interactive elements have visible focus states
- Focus outline uses `--color-accent` for consistency
- Never remove focus outline without replacement

### Motion

- Respect `prefers-reduced-motion` media query
- Hover animations are subtle (no jarring movements)

## Design Token Mapping

How UX decisions map to CSS custom properties:

| UX Goal | Design Token | Value |
|---------|--------------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e |
| Draw attention to contact | `--color-accent` | #e94560 |
| Clean gallery feel | `--color-background` | #ffffff |
| Readable content | `--color-text` | #333333 |
| Elegant headings | `--font-heading` | Georgia, serif |
| Clear body text | `--font-body` | Arial, sans-serif |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale |
| Professional cards | `--border-radius` | 8px |

## Success Metrics

UX goals verification:

1. **First Impression (3 sec test):** User can identify "photographer portfolio" within 3 seconds
2. **Scannability:** All three project types visible without scrolling on desktop
3. **Mobile Usability:** Full journey completable with thumb-only navigation
4. **CTA Visibility:** Contact button visible in hero without scrolling
5. **Load Performance:** Perceived instant load (no layout shift)
