# Test Suite: Alex Chen Photography Portfolio

End-to-end test suite using Playwright with `@seontechnologies/playwright-utils` fixtures.

## Setup

```bash
# Install dependencies
npm install

# Install Playwright browsers
npx playwright install --with-deps
```

## Running Tests

```bash
# Run all tests (default: chromium)
npm run test:e2e

# Run with visible browser
npm run test:e2e:headed

# Run with debugger (step through tests)
npm run test:e2e:debug

# Run with Playwright UI (interactive mode)
npm run test:e2e:ui

# Run specific project (browser/device)
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit
npx playwright test --project=mobile-chrome
npx playwright test --project=mobile-safari

# Run specific test file
npx playwright test tests/e2e/homepage.spec.ts

# Run tests matching pattern
npx playwright test -g "hero section"
```

## Architecture

```
tests/
├── e2e/                      # End-to-end test specs
│   ├── homepage.spec.ts      # Homepage structure and content tests
│   └── accessibility.spec.ts # Accessibility validation tests
├── support/
│   ├── fixtures/
│   │   ├── index.ts          # Merged fixtures (import from here)
│   │   └── factories.ts      # Data factories for test data
│   └── helpers/
│       ├── selectors.ts      # CSS selector constants (BEM classes)
│       └── assertions.ts     # Reusable assertion helpers
└── README.md                 # This file
```

## Test Fixtures

Import from `tests/support/fixtures/index.ts` for all tests:

```typescript
import { test, expect } from '../support/fixtures';

test('example', async ({ page, log, networkErrorMonitor }) => {
  // log - Playwright report-integrated logging
  await log.step('Navigating to homepage');

  // networkErrorMonitor - Automatic HTTP error detection
  await page.goto('/');
  expect(networkErrorMonitor.getErrors()).toHaveLength(0);
});
```

### Available Fixtures

| Fixture | Source | Purpose |
|---------|--------|---------|
| `log` | playwright-utils | Structured logging in test reports |
| `recurse` | playwright-utils | Cypress-style polling for async conditions |
| `networkErrorMonitor` | playwright-utils | Automatic HTTP 4xx/5xx detection |

## Best Practices

### Selectors

Use BEM class selectors defined in `tests/support/helpers/selectors.ts`:

```typescript
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';

// Prefer semantic selectors
await page.locator(heroSelectors.name);  // .hero__name
await page.locator(projectsSelectors.card);  // .projects__card
```

### Test Isolation

Each test runs in a fresh browser context. No cleanup needed.

### Given/When/Then Format

```typescript
test('should display hero section', async ({ page, log }) => {
  // Given: User navigates to homepage
  await page.goto('/');

  // When: Page loads
  await log.step('Verifying hero section');

  // Then: Hero section should be visible
  await expect(page.locator('.hero')).toBeVisible();
});
```

### Assertions

Use helpers from `tests/support/helpers/assertions.ts`:

```typescript
import { assertHeroSection, assertProjectsSection } from '../support/helpers/assertions';

await assertHeroSection(page);
await assertProjectsSection(page, 3);  // Expects 3 cards
```

## CI Integration

### GitHub Actions

```yaml
- name: Run E2E tests
  run: npm run test:e2e
  env:
    CI: true

- name: Upload test artifacts
  if: failure()
  uses: actions/upload-artifact@v4
  with:
    name: test-results
    path: |
      test-results/
      playwright-report/
```

### Artifacts

On failure, tests capture:
- `test-results/` - Screenshots, videos, traces
- `playwright-report/` - HTML report (run `npx playwright show-report`)

## Knowledge Base References

This framework follows patterns from:
- `fixtures-composition.md` - mergeTests for combined fixtures
- `playwright-config.md` - Environment config, timeouts, artifacts
- `data-factories.md` - Factory patterns for test data
- `network-first.md` - Network error monitoring

See `@seontechnologies/playwright-utils` documentation for advanced patterns.
