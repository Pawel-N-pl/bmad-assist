/**
 * Accessibility E2E Tests for Alex Chen Photography Portfolio
 *
 * Validates basic accessibility requirements for the static portfolio site.
 * Note: For full accessibility auditing, consider adding @axe-core/playwright.
 */
import { test, expect } from '../support/fixtures';

test.describe('Accessibility', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should have proper heading hierarchy', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Checking heading hierarchy');

    // When: Page loads
    // Then: Should have exactly one h1
    const h1Elements = page.locator('h1');
    await expect(h1Elements).toHaveCount(1);

    // Then: h2 elements should exist for sections
    const h2Elements = page.locator('h2');
    await expect(h2Elements.first()).toBeVisible();
  });

  test('should have alt attributes on all images', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Checking image alt attributes');

    // When: Page loads
    const images = page.locator('img');
    const imageCount = await images.count();

    // Then: All images should have alt attributes (can be empty for decorative)
    for (let i = 0; i < imageCount; i++) {
      const img = images.nth(i);
      const alt = await img.getAttribute('alt');
      expect(alt).not.toBeNull();
    }
  });

  test('should have meaningful link text', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Checking link accessibility');

    // When: Page loads
    const links = page.locator('a');
    const linkCount = await links.count();

    // Then: Links should have accessible text
    for (let i = 0; i < linkCount; i++) {
      const link = links.nth(i);
      const text = await link.textContent();
      const ariaLabel = await link.getAttribute('aria-label');

      // Link should have text content or aria-label
      const hasAccessibleName = (text && text.trim().length > 0) || ariaLabel;
      expect(hasAccessibleName).toBeTruthy();
    }
  });

  test('should have sufficient color contrast (manual check)', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Checking CSS custom properties for theming');

    // When: Page loads
    // Then: CSS custom properties should be defined
    const body = page.locator('body');
    const primaryColor = await body.evaluate((el) => getComputedStyle(el).getPropertyValue('--color-primary').trim());
    const textColor = await body.evaluate((el) => getComputedStyle(el).getPropertyValue('--color-text').trim());

    // Variables should be defined (actual contrast ratio requires visual testing)
    expect(primaryColor).not.toBe('');
    expect(textColor).not.toBe('');
  });

  test('should be keyboard navigable', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Testing keyboard navigation');

    // When: User presses Tab
    await page.keyboard.press('Tab');

    // Then: First focusable element should receive focus
    const focusedElement = page.locator(':focus');
    await expect(focusedElement).toBeVisible();
  });
});
