/**
 * Homepage E2E Tests for Alex Chen Photography Portfolio
 *
 * Tests the main landing page structure, content, and responsiveness.
 *
 * Test Strategy:
 * - Given/When/Then format for clarity
 * - BEM class selectors for stability (no data-testid in static HTML)
 * - Network error monitoring via playwright-utils
 */
import { test, expect } from '../support/fixtures';
import { assertHeroSection, assertProjectsSection, assertSemanticStructure } from '../support/helpers/assertions';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';

test.describe('Homepage', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
  });

  test('should display hero section with photographer name and tagline', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Verifying hero section content');

    // When: The page loads
    // Then: Hero section should be visible with correct content
    await assertHeroSection(page);

    // Verify specific content
    const heroName = page.locator(heroSelectors.name);
    await expect(heroName).toContainText('Alex Chen');

    const tagline = page.locator(heroSelectors.tagline);
    await expect(tagline).toBeVisible();
  });

  test('should display projects section with 3 portfolio cards', async ({ page, log }) => {
    // Given: User is on the homepage
    await log.step('Verifying projects section');

    // When: The page is fully loaded
    // Then: Projects section should show exactly 3 cards
    await assertProjectsSection(page, 3);

    // Verify card categories exist
    const cardTitles = page.locator(projectsSelectors.cardTitle);
    await expect(cardTitles).toHaveCount(3);
  });

  test('should have proper semantic HTML structure', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await log.step('Verifying semantic HTML structure');

    // When: The page loads
    // Then: Proper semantic elements should be present
    await assertSemanticStructure(page);
  });

  test('should have CTA button linking to contact section', async ({ page, log }) => {
    // Given: User is on the homepage
    await log.step('Verifying CTA functionality');

    // When: User clicks the CTA button
    const ctaButton = page.locator(heroSelectors.cta);
    await expect(ctaButton).toBeVisible();

    // Then: CTA should have appropriate link (anchor or mailto)
    const href = await ctaButton.getAttribute('href');
    expect(href).toBeTruthy();
  });
});

test.describe('Homepage - Responsive Design', () => {
  test('should adapt layout for mobile viewport', async ({ page, isMobile, log }) => {
    // Given: User views on mobile device
    await page.goto('/');
    await log.step(`Testing ${isMobile ? 'mobile' : 'desktop'} layout`);

    // When: Page loads
    // Then: Hero section should be visible
    await assertHeroSection(page);

    // Projects grid should be visible
    const projectsGrid = page.locator(projectsSelectors.grid);
    await expect(projectsGrid).toBeVisible();
  });
});

test.describe('Homepage - Performance', () => {
  test('should load without HTTP errors', async ({ page, networkErrorMonitor }) => {
    // Given: Network error monitoring is active
    // When: Page loads
    await page.goto('/');

    // Then: No HTTP 4xx/5xx errors should occur
    const errors = networkErrorMonitor.getErrors();
    expect(errors).toHaveLength(0);
  });
});
