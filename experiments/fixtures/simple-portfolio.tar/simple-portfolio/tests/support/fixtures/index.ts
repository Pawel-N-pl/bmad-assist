/**
 * Merged Fixtures for Alex Chen Photography Portfolio
 *
 * Combines playwright-utils fixtures with custom project fixtures using mergeTests.
 * Import { test, expect } from this file in all test files for consistent utilities.
 *
 * @see https://playwright.dev/docs/test-fixtures
 */
import { mergeTests } from '@playwright/test';
import { test as logFixture } from '@seontechnologies/playwright-utils/log/fixtures';
import { test as recurseFixture } from '@seontechnologies/playwright-utils/recurse/fixtures';
import { test as networkErrorMonitorFixture } from '@seontechnologies/playwright-utils/network-error-monitor/fixtures';

// Merge all fixtures into unified test object
export const test = mergeTests(logFixture, recurseFixture, networkErrorMonitorFixture);

export { expect } from '@playwright/test';
