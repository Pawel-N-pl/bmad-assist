    # Workflow Plan: testarch-nfr

    ## Create Mode (steps-c)
    - step-01-load-context.md

- step-02-define-thresholds.md
- step-03-gather-evidence.md
- step-04-evaluate-and-score.md
- step-05-generate-report.md

  ## Validate Mode (steps-v)
  - step-01-validate.md

  ## Edit Mode (steps-e)
  - step-01-assess.md
  - step-02-apply-edit.md

  ## Outputs
  - {output_folder}/nfr-assessment.md
