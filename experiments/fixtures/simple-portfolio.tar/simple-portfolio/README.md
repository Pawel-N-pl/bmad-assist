# Simple Portfolio - Test Fixture

Test fixture for bmad-assist benchmarking and development.

## Resetting State

```bash
# Quick reset (sprint-status regenerates automatically)
rm -f .bmad-assist/state.yaml
rm -f _bmad-output/implementation-artifacts/sprint-status.yaml

# Full reset from tar (if available)
rm -rf experiments/fixtures/simple-portfolio
tar -xf experiments/fixtures/simple-portfolio.tar -C experiments/fixtures/
```

## Structure

- `docs/epics/` - Epic definitions (2 epics, 4 stories total)
- `_bmad-output/implementation-artifacts/` - Generated artifacts
- `.bmad-assist/state.yaml` - Loop state (delete to reset)
